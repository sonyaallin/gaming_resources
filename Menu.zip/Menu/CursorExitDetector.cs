using UnityEngine;


public class CursorExitDetector : MonoBehaviour
{
    [SerializeField]
     AudioSource audioSource; // Assign your audio source in the inspector 

    void Update()
    {
        if (RectTransformUtility.RectangleContainsScreenPoint(GetComponent<RectTransform>(), Input.mousePosition))
        {
            audioSource.Play(); // Play the audio when cursor leaves the canvas
        }
    }
}
