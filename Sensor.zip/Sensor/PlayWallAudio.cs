using System.Collections;
using UnityEngine;

public class PlayWallAudio : MonoBehaviour
{
    // Time delay between audio sources
    public float delay = 3f;
    //You will have to add your own walls yourself with the tag Wall and add a audio source to them and make the spatial blend 3d with your own audio 
    void Update()
    {
        // Check if the Spacebar is pressed
        if (Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine(PlayWallSounds());
        }
    }

    IEnumerator PlayWallSounds()
    {
        // Find all game objects with the tag "Wall"
        GameObject[] wallObjects = GameObject.FindGameObjectsWithTag("Wall");

        // Create a list to store walls with their distances
        System.Collections.Generic.List<WallDistance> wallDistances = new System.Collections.Generic.List<WallDistance>();

        // Get the player object (assuming this script is attached to the player)
        Transform player = transform;

        // Calculate the distance of each wall to the player
        foreach (GameObject wall in wallObjects)
        {
            // Calculate the distance from the player to the wall
            float distance = Vector3.Distance(wall.transform.position, player.position);

            // Add the wall and its distance to the list
            wallDistances.Add(new WallDistance(wall, distance));
        }

        // Sort the list by distance (closest first)
        wallDistances.Sort((x, y) => x.distance.CompareTo(y.distance));

        // Loop through each wall object in order of distance
        foreach (WallDistance wallDistance in wallDistances)
        {
            // Get the AudioSource component of the wall
            AudioSource audioSource = wallDistance.wall.GetComponent<AudioSource>();
            if (audioSource != null)
            {
                // Play the audio
                audioSource.Play();
                Debug.Log("Found wall");
            }

            // Wait for the specified delay before moving to the next
            yield return new WaitForSeconds(delay);
        }
    }

    // Helper class to store wall and its distance
    private class WallDistance
    {
        public GameObject wall;
        public float distance;

        public WallDistance(GameObject wall, float distance)
        {
            this.wall = wall;
            this.distance = distance;
        }
    }
}