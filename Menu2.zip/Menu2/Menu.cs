using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    public Button[] buttons; // Array to store the buttons
    public float fadeDuration = 1f; // Duration of the fade effect
    private float[] targetAlpha = new float[3]; // Target alpha values for each button
    private float[] currentAlpha = new float[3]; // Current alpha values for each button
    private float fadeSpeed; // Speed at which buttons fade in or out
    [SerializeField]
    private int variableValue = 0; // Example variable (0, 1, or 2 corresponding to the buttons)

    // Start is called before the first frame update
    void Start()
    {
        if (buttons.Length != 3)
        {
            Debug.LogError("There should be exactly 3 buttons assigned.");
            return;
        }

        // Initialize the target alpha values for the buttons (1 = fully visible, 0 = fully transparent)
        for (int i = 0; i < buttons.Length; i++)
        {
            targetAlpha[i] = 0f;  // Initially, all buttons are faded out
            currentAlpha[i] = 0f;
        }

        fadeSpeed = 1f / fadeDuration; // Calculate the speed to fade within the given duration
        UpdateButtonVisibility(variableValue); // Update button visibility based on initial variableValue
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0) && variableValue == 2)
            {
                Debug.Log("Exit");
            Application.Quit();
        }
        if (Input.GetKeyDown(KeyCode.UpArrow))
                {
            variableValue -= 1;
            }
        if(Input.GetKeyDown(KeyCode.DownArrow))
                {
            variableValue += 1;
            }
        if (variableValue > 2)
        {
            variableValue = 0; // Reset to 0 if it exceeds 2
        }
        else if (variableValue < 0)
        {
            variableValue = 2; // Set to 2 if it goes below 0
        }
        // Ensure that button visibility is updated each frame based on variableValue
        UpdateButtonVisibility(variableValue);

        // Update the button's alpha values gradually to fade them in or out
        for (int i = 0; i < buttons.Length; i++)
        {
            Image buttonImage = buttons[i].GetComponent<Image>();
            if (buttonImage != null)
            {
                // Smoothly adjust the alpha value
                currentAlpha[i] = Mathf.MoveTowards(currentAlpha[i], targetAlpha[i], fadeSpeed * Time.deltaTime);
                Color currentColor = buttonImage.color;
                buttonImage.color = new Color(currentColor.r, currentColor.g, currentColor.b, currentAlpha[i]);

                // Set the interactability based on alpha value
                buttons[i].interactable = currentAlpha[i] > 0.1f; // Button is interactable if visible enough
            }
        }
    }

    // Function to change which button is visible and interactable based on the variableValue (0, 1, or 2)
    private void UpdateButtonVisibility(int variable)
    {
        // Fade out all buttons first
        for (int i = 0; i < buttons.Length; i++)
        {
            targetAlpha[i] = 0f;  // Fade out all buttons
        }

        // Set the selected button visible (based on variableValue)
        if (variable >= 0 && variable < buttons.Length)
        {
            targetAlpha[variable] = 1f; // Make the selected button fully visible
        }

        // Adjust interactability for buttons based on visibility
        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].interactable = targetAlpha[i] > 0.1f; // Button is interactable only if it's visible enough
        }
    }

    // Example function to change variableValue dynamically (you can use any input or trigger)
    public void SetVariableValue(int value)
    {
        if (value >= 0 && value < buttons.Length)
        {
            variableValue = value;
        }
    }


}
